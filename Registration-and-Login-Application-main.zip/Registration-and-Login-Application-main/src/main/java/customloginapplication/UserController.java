package customloginapplication;

import java.io.IOException;
import java.security.Principal;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.oauth2.resourceserver.OAuth2ResourceServerSecurityMarker;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import customloginapplication.dto.UserDto;
import customloginapplication.service.UserService;
import jakarta.servlet.http.HttpServletResponse;
import customloginapplication.model.*;


import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.PageSize;


@Controller
public class UserController {
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	private UserService userService;
	public UserController(UserService userService) {
	
		this.userService = userService;
	}

	@GetMapping("/home")
	public String home(Model model, Principal principal) {
		UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		model.addAttribute("userdetail" , userDetails);
		return "home";
	}
	
	@GetMapping("/login")
	public String login(Model model, UserDto userDto) {
		model.addAttribute("user", userDto);
		return "login";
	}
	
	
	@GetMapping("/register")
	public String register(Model model, UserDto userDto) {
		
		model.addAttribute("user", userDto);
		return "register";
	}
	
	@PostMapping("/register")
	public String registerSave(@ModelAttribute("user") UserDto userDto, Model model) {
		User user = userService.findByUsername(userDto.getUsername());
		if (user != null) {
			model.addAttribute("userexist", user);
			return "register";
			
		}
		userService.save(userDto);
		return "redirect:/register?success";
	}
	
	
	 @GetMapping("/graph")
	    public String getPieChart(Model model,Principal principal) {
			UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
			model.addAttribute("userdetail" , userDetails);
	        Map<String, Integer> graphData = new TreeMap<String, Integer>();
	        graphData.put("2016", 147);
	        graphData.put("2017", 1256);
	        graphData.put("2018", 3856);
	        graphData.put("2019", 19807);
	    	model.addAttribute("chartData", graphData);
	        return "graph";
	    }
	 
	 
	 @GetMapping("/graphpdf") 
	 public String generatePdf(Model model) throws DocumentException, IOException {
		 Document document = new Document(PageSize.A4);
		  Map<String, Integer> graphData = new TreeMap<String, Integer>();
	        graphData.put("2016", 147);
	        graphData.put("2017", 1256);
	        graphData.put("2018", 3856);
	        graphData.put("2019", 19807);
	    	model.addAttribute("chartData", graphData);
	    	document.add((Element) model);
	    	document.close();
	    	return "graphpdf";
	 }
	  
	 

}
